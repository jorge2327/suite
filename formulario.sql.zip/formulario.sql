-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- Servidor: localhost
-- Tiempo de generación: 09-06-2016 a las 18:57:15
-- Versión del servidor: 5.0.51
-- Versión de PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- Base de datos: `formulario`
-- 

-- --------------------------------------------------------

-- 
-- Estructura de tabla para la tabla `tabla`
-- 

CREATE TABLE `tabla` (
  `id` int(5) unsigned NOT NULL auto_increment,
  `nombre` varchar(50) collate utf8_spanish_ci NOT NULL,
  `pw` varchar(50) collate utf8_spanish_ci NOT NULL,
  `cate` int(5) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 COLLATE=utf8_spanish_ci AUTO_INCREMENT=9 ;

-- 
-- Volcar la base de datos para la tabla `tabla`
-- 

INSERT INTO `tabla` VALUES (1, 'jorge', 'secret', 0);
INSERT INTO `tabla` VALUES (2, '', 'flores', 0);
INSERT INTO `tabla` VALUES (3, 'carolina', 'flores', 0);
INSERT INTO `tabla` VALUES (4, 'osa', 'flores', 1);
INSERT INTO `tabla` VALUES (5, 'sda', 'asd', 0);
INSERT INTO `tabla` VALUES (6, '', 'sdas', 0);
INSERT INTO `tabla` VALUES (7, 'moy', 'moy', 2);
INSERT INTO `tabla` VALUES (8, 'jorgeffff', '123', 1);
